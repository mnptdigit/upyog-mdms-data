This folder contains master data for Water Charges module
